
void PMIC_init(void);
