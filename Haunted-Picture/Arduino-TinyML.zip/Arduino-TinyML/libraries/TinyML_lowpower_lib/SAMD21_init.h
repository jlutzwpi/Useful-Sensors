
void SAMD21_init(byte waitBeforeSerialPort);

#define PORSTB 24  
#define TINYML_CS 18
#define OSC32K_OUT_PIN 3
