/*
 * Copyright (c) 2021 Syntiant Corp.  All rights reserved.
 * Contact at http://www.syntiant.com
 *
 * This software is available to you under a choice of one of two licenses.
 * You may choose to be licensed under the terms of the GNU General Public
 * License (GPL) Version 2, available from the file LICENSE in the main
 * directory of this source tree, or the OpenIB.org BSD license below.  Any
 * code involving Linux software will require selection of the GNU General
 * Public License (GPL) Version 2.
 *
 * OPENIB.ORG BSD LICENSE
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

//#include <NDP.h>
//#include <NDP_utils.h>
#include <Arduino.h>
//#include "TinyML_init.h"
//#include "NDP_loadModel.h"
//#include "microSDUtils.h"
//#include "SAMD21_init.h"
//#include "NDP_init.h"
#include "blinkLED.h"

#define    LED_RED LED_BUILTIN
#define    LED_BLUE A4
#define    LED_GREEN A5

void blinkRed(int n, int del){
  for (int i=0; i<n; i++){
    digitalWrite(LED_RED,HIGH);
    delay(del);
    digitalWrite(LED_RED,LOW);
    delay(del);
  }
}

void blinkGreen(int n, int del){
  for (int i=0; i<n; i++){
    digitalWrite(LED_GREEN,HIGH);
    delay(del);
    digitalWrite(LED_GREEN,LOW);
    delay(del);
  }
}

void blinkBlue(int n, int del){
  for (int i=0; i<n; i++){
    digitalWrite(LED_BLUE,HIGH);
    delay(del);
    digitalWrite(LED_BLUE,LOW);
    delay(del);
  }
}

void blinkPurple(int n, int del){
  for (int i=0; i<n; i++){
    digitalWrite(LED_BLUE,HIGH);
    digitalWrite(LED_RED,HIGH);
    delay(del);
    digitalWrite(LED_BLUE,LOW);
    digitalWrite(LED_RED,LOW);
    delay(del);
  }
}

void blinkYellow(int n, int del){
  for (int i=0; i<n; i++){
    digitalWrite(LED_GREEN,HIGH);
    digitalWrite(LED_RED,HIGH);
    delay(del);
    digitalWrite(LED_GREEN,LOW);
    digitalWrite(LED_RED,LOW);
    delay(del);
  }
}

void blinkWhite(int n, int del){
  for (int i=0; i<n; i++){
    digitalWrite(LED_BLUE,HIGH);
    digitalWrite(LED_GREEN,HIGH);
    digitalWrite(LED_RED,HIGH);
    delay(del);
    digitalWrite(LED_GREEN,LOW);
    digitalWrite(LED_RED,LOW);
    digitalWrite(LED_BLUE,LOW);
    delay(del);
  }
}

void digitToLEDblinking(int n, int del){
  if ( n == 0) blinkRed(1, del);
  if ( n == 1) blinkGreen(1, del);
  if ( n == 2) blinkBlue(1, del);
  if ( n == 3) blinkPurple(1, del);
  if ( n == 4) blinkYellow(1, del);
  if ( n == 5) blinkRed(2, del);
  if ( n == 6) blinkGreen(2, del);
  if ( n == 7) blinkBlue(2, del);
  if ( n == 8) blinkPurple(2, del);
  if ( n == 9) blinkYellow(2, del);  
}

void doubleDigitRGBDisplay(int fileCounter){
  Serial.print("Current file number: ");
  Serial.println(fileCounter);
  int secondDigit = int(fileCounter / 10);                  // Finding 2nd Decimal digit
  if ( (fileCounter % 10) == 0){                            // Finding onset of decade
    blinkWhite(10,25);                                      // Multiple White LED blink shows the start of the decade 
    delay(500);
    digitToLEDblinking(secondDigit, 500);                   // single RED =0,Green =1,Blue =2, purple(red+blue) =3, yellow(red+green) =4, double Red=5, Green=6, Blue=7, purple=8, yellow=9
    delay(500);
  }
  blinkWhite(1,1000);                                       // Solid white LED indicates start of least significant digit
  digitToLEDblinking(fileCounter % 10, 500);                // least significant digit
}
