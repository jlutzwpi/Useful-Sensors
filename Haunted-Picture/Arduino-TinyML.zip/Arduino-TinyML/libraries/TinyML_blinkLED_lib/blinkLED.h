
void blinkRed(int n, int del);
void blinkGreen(int n, int del);
void blinkBlue(int n, int del);
void blinkPurple(int n, int del);
void blinkYellow(int n, int del);
void blinkWhite(int n, int del);
void digitToLEDblinking(int n, int del);
void doubleDigitRGBDisplay(int fileCounter);

