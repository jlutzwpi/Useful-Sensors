
void dir(void);